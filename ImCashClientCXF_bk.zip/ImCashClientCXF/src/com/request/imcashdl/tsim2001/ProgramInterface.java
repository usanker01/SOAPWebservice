
package com.request.imcashdl.tsim2001;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgramInterface complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProgramInterface"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dlr_record"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="dlr_transaction"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="dlr_ctl_key"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="dlr_control_2"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="3"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_account"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="14"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_tran_code"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                   &lt;maxLength value="2"/&gt;
 *                                   &lt;whiteSpace value="collapse"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_trace"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
 *                                   &lt;maxInclusive value="9999999"/&gt;
 *                                   &lt;minInclusive value="0"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_80_tran"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="dlr_80_82_83_user_code"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="4"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_80_82_83_drcr_amt"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *                                             &lt;totalDigits value="13"/&gt;
 *                                             &lt;fractionDigits value="2"/&gt;
 *                                             &lt;minInclusive value="0"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_80_check_no"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedLong"&gt;
 *                                             &lt;maxInclusive value="9999999999"/&gt;
 *                                             &lt;minInclusive value="0"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_80_desc"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="3"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_80_bai_code"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="5"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_80_82_83_tran_flag"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="1"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_source_info"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="dlr_suspect_debit"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="1"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_pico_tran_eti"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *                                             &lt;totalDigits value="15"/&gt;
 *                                             &lt;fractionDigits value="0"/&gt;
 *                                             &lt;minInclusive value="0"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_pico_tran_cc"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="3"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_date"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="8"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_time"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *                                             &lt;totalDigits value="7"/&gt;
 *                                             &lt;fractionDigits value="0"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_ancillary_src"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedShort"&gt;
 *                                             &lt;maxInclusive value="999"/&gt;
 *                                             &lt;minInclusive value="0"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_15_digit_ref_no"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
 *                                   &lt;totalDigits value="15"/&gt;
 *                                   &lt;fractionDigits value="0"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_pay_ovr_ind"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                   &lt;maxLength value="1"/&gt;
 *                                   &lt;whiteSpace value="collapse"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="dlr_desc_tran"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="dlr_seg_occurs"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="2"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_seg_length"&gt;
 *                                         &lt;simpleType&gt;
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                             &lt;maxLength value="2"/&gt;
 *                                             &lt;whiteSpace value="collapse"/&gt;
 *                                           &lt;/restriction&gt;
 *                                         &lt;/simpleType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="dlr_univ_desc" maxOccurs="10" minOccurs="10"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="dlr_desc_line"&gt;
 *                                                   &lt;simpleType&gt;
 *                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                                       &lt;maxLength value="60"/&gt;
 *                                                       &lt;whiteSpace value="collapse"/&gt;
 *                                                     &lt;/restriction&gt;
 *                                                   &lt;/simpleType&gt;
 *                                                 &lt;/element&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProgramInterface", propOrder = {
    "dlrRecord"
})
public class ProgramInterface {

    @XmlElement(name = "dlr_record", required = true)
    protected ProgramInterface.DlrRecord dlrRecord;

    /**
     * Gets the value of the dlrRecord property.
     * 
     * @return
     *     possible object is
     *     {@link ProgramInterface.DlrRecord }
     *     
     */
    public ProgramInterface.DlrRecord getDlrRecord() {
        return dlrRecord;
    }

    /**
     * Sets the value of the dlrRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProgramInterface.DlrRecord }
     *     
     */
    public void setDlrRecord(ProgramInterface.DlrRecord value) {
        this.dlrRecord = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="dlr_transaction"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="dlr_ctl_key"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="dlr_control_2"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="3"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_account"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="14"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_tran_code"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                         &lt;maxLength value="2"/&gt;
     *                         &lt;whiteSpace value="collapse"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_trace"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
     *                         &lt;maxInclusive value="9999999"/&gt;
     *                         &lt;minInclusive value="0"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_80_tran"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="dlr_80_82_83_user_code"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="4"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_80_82_83_drcr_amt"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
     *                                   &lt;totalDigits value="13"/&gt;
     *                                   &lt;fractionDigits value="2"/&gt;
     *                                   &lt;minInclusive value="0"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_80_check_no"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedLong"&gt;
     *                                   &lt;maxInclusive value="9999999999"/&gt;
     *                                   &lt;minInclusive value="0"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_80_desc"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="3"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_80_bai_code"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="5"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_80_82_83_tran_flag"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="1"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_source_info"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="dlr_suspect_debit"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="1"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_pico_tran_eti"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
     *                                   &lt;totalDigits value="15"/&gt;
     *                                   &lt;fractionDigits value="0"/&gt;
     *                                   &lt;minInclusive value="0"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_pico_tran_cc"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="3"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_date"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="8"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_time"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
     *                                   &lt;totalDigits value="7"/&gt;
     *                                   &lt;fractionDigits value="0"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_ancillary_src"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedShort"&gt;
     *                                   &lt;maxInclusive value="999"/&gt;
     *                                   &lt;minInclusive value="0"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_15_digit_ref_no"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
     *                         &lt;totalDigits value="15"/&gt;
     *                         &lt;fractionDigits value="0"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_pay_ovr_ind"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                         &lt;maxLength value="1"/&gt;
     *                         &lt;whiteSpace value="collapse"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="dlr_desc_tran"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="dlr_seg_occurs"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="2"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_seg_length"&gt;
     *                               &lt;simpleType&gt;
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                   &lt;maxLength value="2"/&gt;
     *                                   &lt;whiteSpace value="collapse"/&gt;
     *                                 &lt;/restriction&gt;
     *                               &lt;/simpleType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="dlr_univ_desc" maxOccurs="10" minOccurs="10"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="dlr_desc_line"&gt;
     *                                         &lt;simpleType&gt;
     *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                                             &lt;maxLength value="60"/&gt;
     *                                             &lt;whiteSpace value="collapse"/&gt;
     *                                           &lt;/restriction&gt;
     *                                         &lt;/simpleType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dlrTransaction"
    })
    public static class DlrRecord {

        @XmlElement(name = "dlr_transaction", required = true)
        protected ProgramInterface.DlrRecord.DlrTransaction dlrTransaction;

        /**
         * Gets the value of the dlrTransaction property.
         * 
         * @return
         *     possible object is
         *     {@link ProgramInterface.DlrRecord.DlrTransaction }
         *     
         */
        public ProgramInterface.DlrRecord.DlrTransaction getDlrTransaction() {
            return dlrTransaction;
        }

        /**
         * Sets the value of the dlrTransaction property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProgramInterface.DlrRecord.DlrTransaction }
         *     
         */
        public void setDlrTransaction(ProgramInterface.DlrRecord.DlrTransaction value) {
            this.dlrTransaction = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="dlr_ctl_key"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="dlr_control_2"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="3"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_account"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="14"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_tran_code"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *               &lt;maxLength value="2"/&gt;
         *               &lt;whiteSpace value="collapse"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_trace"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
         *               &lt;maxInclusive value="9999999"/&gt;
         *               &lt;minInclusive value="0"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_80_tran"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="dlr_80_82_83_user_code"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="4"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_80_82_83_drcr_amt"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
         *                         &lt;totalDigits value="13"/&gt;
         *                         &lt;fractionDigits value="2"/&gt;
         *                         &lt;minInclusive value="0"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_80_check_no"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedLong"&gt;
         *                         &lt;maxInclusive value="9999999999"/&gt;
         *                         &lt;minInclusive value="0"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_80_desc"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="3"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_80_bai_code"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="5"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_80_82_83_tran_flag"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="1"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_source_info"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="dlr_suspect_debit"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="1"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_pico_tran_eti"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
         *                         &lt;totalDigits value="15"/&gt;
         *                         &lt;fractionDigits value="0"/&gt;
         *                         &lt;minInclusive value="0"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_pico_tran_cc"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="3"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_date"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="8"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_time"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
         *                         &lt;totalDigits value="7"/&gt;
         *                         &lt;fractionDigits value="0"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_ancillary_src"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedShort"&gt;
         *                         &lt;maxInclusive value="999"/&gt;
         *                         &lt;minInclusive value="0"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_15_digit_ref_no"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
         *               &lt;totalDigits value="15"/&gt;
         *               &lt;fractionDigits value="0"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_pay_ovr_ind"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *               &lt;maxLength value="1"/&gt;
         *               &lt;whiteSpace value="collapse"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="dlr_desc_tran"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="dlr_seg_occurs"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="2"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_seg_length"&gt;
         *                     &lt;simpleType&gt;
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                         &lt;maxLength value="2"/&gt;
         *                         &lt;whiteSpace value="collapse"/&gt;
         *                       &lt;/restriction&gt;
         *                     &lt;/simpleType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="dlr_univ_desc" maxOccurs="10" minOccurs="10"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="dlr_desc_line"&gt;
         *                               &lt;simpleType&gt;
         *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *                                   &lt;maxLength value="60"/&gt;
         *                                   &lt;whiteSpace value="collapse"/&gt;
         *                                 &lt;/restriction&gt;
         *                               &lt;/simpleType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "dlrCtlKey",
            "dlrTranCode",
            "dlrTrace",
            "dlr80Tran",
            "dlrSourceInfo",
            "dlr15DigitRefNo",
            "dlrPayOvrInd",
            "dlrDescTran"
        })
        public static class DlrTransaction {

            @XmlElement(name = "dlr_ctl_key", required = true)
            protected ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey dlrCtlKey;
            @XmlElement(name = "dlr_tran_code", required = true)
            protected String dlrTranCode;
            @XmlElement(name = "dlr_trace")
            protected long dlrTrace;
            @XmlElement(name = "dlr_80_tran", required = true)
            protected ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran dlr80Tran;
            @XmlElement(name = "dlr_source_info", required = true)
            protected ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo dlrSourceInfo;
            @XmlElement(name = "dlr_15_digit_ref_no", required = true)
            protected BigDecimal dlr15DigitRefNo;
            @XmlElement(name = "dlr_pay_ovr_ind", required = true)
            protected String dlrPayOvrInd;
            @XmlElement(name = "dlr_desc_tran", required = true)
            protected ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran dlrDescTran;

            /**
             * Gets the value of the dlrCtlKey property.
             * 
             * @return
             *     possible object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey }
             *     
             */
            public ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey getDlrCtlKey() {
                return dlrCtlKey;
            }

            /**
             * Sets the value of the dlrCtlKey property.
             * 
             * @param value
             *     allowed object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey }
             *     
             */
            public void setDlrCtlKey(ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey value) {
                this.dlrCtlKey = value;
            }

            /**
             * Gets the value of the dlrTranCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDlrTranCode() {
                return dlrTranCode;
            }

            /**
             * Sets the value of the dlrTranCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDlrTranCode(String value) {
                this.dlrTranCode = value;
            }

            /**
             * Gets the value of the dlrTrace property.
             * 
             */
            public long getDlrTrace() {
                return dlrTrace;
            }

            /**
             * Sets the value of the dlrTrace property.
             * 
             */
            public void setDlrTrace(long value) {
                this.dlrTrace = value;
            }

            /**
             * Gets the value of the dlr80Tran property.
             * 
             * @return
             *     possible object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran }
             *     
             */
            public ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran getDlr80Tran() {
                return dlr80Tran;
            }

            /**
             * Sets the value of the dlr80Tran property.
             * 
             * @param value
             *     allowed object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran }
             *     
             */
            public void setDlr80Tran(ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran value) {
                this.dlr80Tran = value;
            }

            /**
             * Gets the value of the dlrSourceInfo property.
             * 
             * @return
             *     possible object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo }
             *     
             */
            public ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo getDlrSourceInfo() {
                return dlrSourceInfo;
            }

            /**
             * Sets the value of the dlrSourceInfo property.
             * 
             * @param value
             *     allowed object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo }
             *     
             */
            public void setDlrSourceInfo(ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo value) {
                this.dlrSourceInfo = value;
            }

            /**
             * Gets the value of the dlr15DigitRefNo property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getDlr15DigitRefNo() {
                return dlr15DigitRefNo;
            }

            /**
             * Sets the value of the dlr15DigitRefNo property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setDlr15DigitRefNo(BigDecimal value) {
                this.dlr15DigitRefNo = value;
            }

            /**
             * Gets the value of the dlrPayOvrInd property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDlrPayOvrInd() {
                return dlrPayOvrInd;
            }

            /**
             * Sets the value of the dlrPayOvrInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDlrPayOvrInd(String value) {
                this.dlrPayOvrInd = value;
            }

            /**
             * Gets the value of the dlrDescTran property.
             * 
             * @return
             *     possible object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran }
             *     
             */
            public ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran getDlrDescTran() {
                return dlrDescTran;
            }

            /**
             * Sets the value of the dlrDescTran property.
             * 
             * @param value
             *     allowed object is
             *     {@link ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran }
             *     
             */
            public void setDlrDescTran(ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran value) {
                this.dlrDescTran = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="dlr_80_82_83_user_code"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="4"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_80_82_83_drcr_amt"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
             *               &lt;totalDigits value="13"/&gt;
             *               &lt;fractionDigits value="2"/&gt;
             *               &lt;minInclusive value="0"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_80_check_no"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedLong"&gt;
             *               &lt;maxInclusive value="9999999999"/&gt;
             *               &lt;minInclusive value="0"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_80_desc"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="3"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_80_bai_code"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="5"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_80_82_83_tran_flag"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="1"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "dlr808283UserCode",
                "dlr808283DrcrAmt",
                "dlr80CheckNo",
                "dlr80Desc",
                "dlr80BaiCode",
                "dlr808283TranFlag"
            })
            public static class Dlr80Tran {

                @XmlElement(name = "dlr_80_82_83_user_code", required = true)
                protected String dlr808283UserCode;
                @XmlElement(name = "dlr_80_82_83_drcr_amt", required = true)
                protected BigDecimal dlr808283DrcrAmt;
                @XmlElement(name = "dlr_80_check_no")
                protected long dlr80CheckNo;
                @XmlElement(name = "dlr_80_desc", required = true)
                protected String dlr80Desc;
                @XmlElement(name = "dlr_80_bai_code", required = true)
                protected String dlr80BaiCode;
                @XmlElement(name = "dlr_80_82_83_tran_flag", required = true)
                protected String dlr808283TranFlag;

                /**
                 * Gets the value of the dlr808283UserCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlr808283UserCode() {
                    return dlr808283UserCode;
                }

                /**
                 * Sets the value of the dlr808283UserCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlr808283UserCode(String value) {
                    this.dlr808283UserCode = value;
                }

                /**
                 * Gets the value of the dlr808283DrcrAmt property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getDlr808283DrcrAmt() {
                    return dlr808283DrcrAmt;
                }

                /**
                 * Sets the value of the dlr808283DrcrAmt property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setDlr808283DrcrAmt(BigDecimal value) {
                    this.dlr808283DrcrAmt = value;
                }

                /**
                 * Gets the value of the dlr80CheckNo property.
                 * 
                 */
                public long getDlr80CheckNo() {
                    return dlr80CheckNo;
                }

                /**
                 * Sets the value of the dlr80CheckNo property.
                 * 
                 */
                public void setDlr80CheckNo(long value) {
                    this.dlr80CheckNo = value;
                }

                /**
                 * Gets the value of the dlr80Desc property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlr80Desc() {
                    return dlr80Desc;
                }

                /**
                 * Sets the value of the dlr80Desc property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlr80Desc(String value) {
                    this.dlr80Desc = value;
                }

                /**
                 * Gets the value of the dlr80BaiCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlr80BaiCode() {
                    return dlr80BaiCode;
                }

                /**
                 * Sets the value of the dlr80BaiCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlr80BaiCode(String value) {
                    this.dlr80BaiCode = value;
                }

                /**
                 * Gets the value of the dlr808283TranFlag property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlr808283TranFlag() {
                    return dlr808283TranFlag;
                }

                /**
                 * Sets the value of the dlr808283TranFlag property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlr808283TranFlag(String value) {
                    this.dlr808283TranFlag = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="dlr_control_2"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="3"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_account"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="14"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "dlrControl2",
                "dlrAccount"
            })
            public static class DlrCtlKey {

                @XmlElement(name = "dlr_control_2", required = true)
                protected String dlrControl2;
                @XmlElement(name = "dlr_account", required = true)
                protected String dlrAccount;

                /**
                 * Gets the value of the dlrControl2 property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrControl2() {
                    return dlrControl2;
                }

                /**
                 * Sets the value of the dlrControl2 property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrControl2(String value) {
                    this.dlrControl2 = value;
                }

                /**
                 * Gets the value of the dlrAccount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrAccount() {
                    return dlrAccount;
                }

                /**
                 * Sets the value of the dlrAccount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrAccount(String value) {
                    this.dlrAccount = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="dlr_seg_occurs"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="2"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_seg_length"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="2"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_univ_desc" maxOccurs="10" minOccurs="10"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="dlr_desc_line"&gt;
             *                     &lt;simpleType&gt;
             *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *                         &lt;maxLength value="60"/&gt;
             *                         &lt;whiteSpace value="collapse"/&gt;
             *                       &lt;/restriction&gt;
             *                     &lt;/simpleType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "dlrSegOccurs",
                "dlrSegLength",
                "dlrUnivDesc"
            })
            public static class DlrDescTran {

                @XmlElement(name = "dlr_seg_occurs", required = true)
                protected String dlrSegOccurs;
                @XmlElement(name = "dlr_seg_length", required = true)
                protected String dlrSegLength;
                @XmlElement(name = "dlr_univ_desc", required = true)
                protected List<ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc> dlrUnivDesc;

                /**
                 * Gets the value of the dlrSegOccurs property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrSegOccurs() {
                    return dlrSegOccurs;
                }

                /**
                 * Sets the value of the dlrSegOccurs property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrSegOccurs(String value) {
                    this.dlrSegOccurs = value;
                }

                /**
                 * Gets the value of the dlrSegLength property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrSegLength() {
                    return dlrSegLength;
                }

                /**
                 * Sets the value of the dlrSegLength property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrSegLength(String value) {
                    this.dlrSegLength = value;
                }

                /**
                 * Gets the value of the dlrUnivDesc property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the dlrUnivDesc property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getDlrUnivDesc().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc }
                 * 
                 * 
                 */
                public List<ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc> getDlrUnivDesc() {
                    if (dlrUnivDesc == null) {
                        dlrUnivDesc = new ArrayList<ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc>();
                    }
                    return this.dlrUnivDesc;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="dlr_desc_line"&gt;
                 *           &lt;simpleType&gt;
                 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
                 *               &lt;maxLength value="60"/&gt;
                 *               &lt;whiteSpace value="collapse"/&gt;
                 *             &lt;/restriction&gt;
                 *           &lt;/simpleType&gt;
                 *         &lt;/element&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "dlrDescLine"
                })
                public static class DlrUnivDesc {

                    @XmlElement(name = "dlr_desc_line", required = true)
                    protected String dlrDescLine;

                    /**
                     * Gets the value of the dlrDescLine property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDlrDescLine() {
                        return dlrDescLine;
                    }

                    /**
                     * Sets the value of the dlrDescLine property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDlrDescLine(String value) {
                        this.dlrDescLine = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="dlr_suspect_debit"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="1"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_pico_tran_eti"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
             *               &lt;totalDigits value="15"/&gt;
             *               &lt;fractionDigits value="0"/&gt;
             *               &lt;minInclusive value="0"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_pico_tran_cc"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="3"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_date"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
             *               &lt;maxLength value="8"/&gt;
             *               &lt;whiteSpace value="collapse"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_time"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal"&gt;
             *               &lt;totalDigits value="7"/&gt;
             *               &lt;fractionDigits value="0"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="dlr_ancillary_src"&gt;
             *           &lt;simpleType&gt;
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedShort"&gt;
             *               &lt;maxInclusive value="999"/&gt;
             *               &lt;minInclusive value="0"/&gt;
             *             &lt;/restriction&gt;
             *           &lt;/simpleType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "dlrSuspectDebit",
                "dlrPicoTranEti",
                "dlrPicoTranCc",
                "dlrDate",
                "dlrTime",
                "dlrAncillarySrc"
            })
            public static class DlrSourceInfo {

                @XmlElement(name = "dlr_suspect_debit", required = true)
                protected String dlrSuspectDebit;
                @XmlElement(name = "dlr_pico_tran_eti", required = true)
                protected BigDecimal dlrPicoTranEti;
                @XmlElement(name = "dlr_pico_tran_cc", required = true)
                protected String dlrPicoTranCc;
                @XmlElement(name = "dlr_date", required = true)
                protected String dlrDate;
                @XmlElement(name = "dlr_time", required = true)
                protected BigDecimal dlrTime;
                @XmlElement(name = "dlr_ancillary_src")
                protected int dlrAncillarySrc;

                /**
                 * Gets the value of the dlrSuspectDebit property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrSuspectDebit() {
                    return dlrSuspectDebit;
                }

                /**
                 * Sets the value of the dlrSuspectDebit property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrSuspectDebit(String value) {
                    this.dlrSuspectDebit = value;
                }

                /**
                 * Gets the value of the dlrPicoTranEti property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getDlrPicoTranEti() {
                    return dlrPicoTranEti;
                }

                /**
                 * Sets the value of the dlrPicoTranEti property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setDlrPicoTranEti(BigDecimal value) {
                    this.dlrPicoTranEti = value;
                }

                /**
                 * Gets the value of the dlrPicoTranCc property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrPicoTranCc() {
                    return dlrPicoTranCc;
                }

                /**
                 * Sets the value of the dlrPicoTranCc property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrPicoTranCc(String value) {
                    this.dlrPicoTranCc = value;
                }

                /**
                 * Gets the value of the dlrDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDlrDate() {
                    return dlrDate;
                }

                /**
                 * Sets the value of the dlrDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDlrDate(String value) {
                    this.dlrDate = value;
                }

                /**
                 * Gets the value of the dlrTime property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getDlrTime() {
                    return dlrTime;
                }

                /**
                 * Sets the value of the dlrTime property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setDlrTime(BigDecimal value) {
                    this.dlrTime = value;
                }

                /**
                 * Gets the value of the dlrAncillarySrc property.
                 * 
                 */
                public int getDlrAncillarySrc() {
                    return dlrAncillarySrc;
                }

                /**
                 * Sets the value of the dlrAncillarySrc property.
                 * 
                 */
                public void setDlrAncillarySrc(int value) {
                    this.dlrAncillarySrc = value;
                }

            }

        }

    }

}
