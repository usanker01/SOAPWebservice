
package com.boa.json.domain;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "took",
    "timed_out",
    "_shards",
    "_hits"
})
public class NgramTermPrridAnalysisMValid2 {

    @JsonProperty("took")
    private Integer took;
    @JsonProperty("timed_out")
    private Boolean timedOut;
    @JsonProperty("_shards")
    private Shards shards;
    @JsonProperty("_hits")
    private Hits hits;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("took")
    public Integer getTook() {
        return took;
    }

    @JsonProperty("took")
    public void setTook(Integer took) {
        this.took = took;
    }

    public NgramTermPrridAnalysisMValid2 withTook(Integer took) {
        this.took = took;
        return this;
    }

    @JsonProperty("timed_out")
    public Boolean getTimedOut() {
        return timedOut;
    }

    @JsonProperty("timed_out")
    public void setTimedOut(Boolean timedOut) {
        this.timedOut = timedOut;
    }

    public NgramTermPrridAnalysisMValid2 withTimedOut(Boolean timedOut) {
        this.timedOut = timedOut;
        return this;
    }

    @JsonProperty("_shards")
    public Shards getShards() {
        return shards;
    }

    @JsonProperty("_shards")
    public void setShards(Shards shards) {
        this.shards = shards;
    }

    public NgramTermPrridAnalysisMValid2 withShards(Shards shards) {
        this.shards = shards;
        return this;
    }

    @JsonProperty("_hits")
    public Hits getHits() {
        return hits;
    }

    @JsonProperty("_hits")
    public void setHits(Hits hits) {
        this.hits = hits;
    }

    public NgramTermPrridAnalysisMValid2 withHits(Hits hits) {
        this.hits = hits;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public NgramTermPrridAnalysisMValid2 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(took).append(timedOut).append(shards).append(hits).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof NgramTermPrridAnalysisMValid2) == false) {
            return false;
        }
        NgramTermPrridAnalysisMValid2 rhs = ((NgramTermPrridAnalysisMValid2) other);
        return new EqualsBuilder().append(took, rhs.took).append(timedOut, rhs.timedOut).append(shards, rhs.shards).append(hits, rhs.hits).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
