
package com.boa.json.domain;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "master_profile_identifer",
    "party_identifier",
    "path_client_identifer",
    "taxpayer_identifier_number",
    "producer_identifier",
    "LeadFA_Producer_Identifier",
    "individual_first_name",
    "individual_middle_name",
    "individual_last_name",
    "individual_name_prefix",
    "individual_name_suffix",
    "individual_preferred_phone_number",
    "individual_preferred_email_address",
    "primary_residential_address_line",
    "primary_residential_address_city_name",
    "primary_residential_address_state_code",
    "primay_residential_address_state_name",
    "primary_residential_address_postal_code",
    "primary_residential_address_country_name",
    "ccdp_asset_type",
    "Profile_affiliate_sharing_indicator",
    "test_document_indicator",
    "test_case_identifier"
})
public class Source {

    @JsonProperty("master_profile_identifer")
    private String masterProfileIdentifer;
    @JsonProperty("party_identifier")
    private String partyIdentifier;
    @JsonProperty("path_client_identifer")
    private String pathClientIdentifer;
    @JsonProperty("taxpayer_identifier_number")
    private String taxpayerIdentifierNumber;
    @JsonProperty("producer_identifier")
    private String producerIdentifier;
    @JsonProperty("LeadFA_Producer_Identifier")
    private String leadFAProducerIdentifier;
    @JsonProperty("individual_first_name")
    private String individualFirstName;
    @JsonProperty("individual_middle_name")
    private String individualMiddleName;
    @JsonProperty("individual_last_name")
    private String individualLastName;
    @JsonProperty("individual_name_prefix")
    private String individualNamePrefix;
    @JsonProperty("individual_name_suffix")
    private String individualNameSuffix;
    @JsonProperty("individual_preferred_phone_number")
    private String individualPreferredPhoneNumber;
    @JsonProperty("individual_preferred_email_address")
    private String individualPreferredEmailAddress;
    @JsonProperty("primary_residential_address_line")
    private String primaryResidentialAddressLine;
    @JsonProperty("primary_residential_address_city_name")
    private String primaryResidentialAddressCityName;
    @JsonProperty("primary_residential_address_state_code")
    private String primaryResidentialAddressStateCode;
    @JsonProperty("primay_residential_address_state_name")
    private String primayResidentialAddressStateName;
    @JsonProperty("primary_residential_address_postal_code")
    private String primaryResidentialAddressPostalCode;
    @JsonProperty("primary_residential_address_country_name")
    private String primaryResidentialAddressCountryName;
    @JsonProperty("ccdp_asset_type")
    private String ccdpAssetType;
    @JsonProperty("Profile_affiliate_sharing_indicator")
    private String profileAffiliateSharingIndicator;
    @JsonProperty("test_document_indicator")
    private String testDocumentIndicator;
    @JsonProperty("test_case_identifier")
    private String testCaseIdentifier;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("master_profile_identifer")
    public String getMasterProfileIdentifer() {
        return masterProfileIdentifer;
    }

    @JsonProperty("master_profile_identifer")
    public void setMasterProfileIdentifer(String masterProfileIdentifer) {
        this.masterProfileIdentifer = masterProfileIdentifer;
    }

    public Source withMasterProfileIdentifer(String masterProfileIdentifer) {
        this.masterProfileIdentifer = masterProfileIdentifer;
        return this;
    }

    @JsonProperty("party_identifier")
    public String getPartyIdentifier() {
        return partyIdentifier;
    }

    @JsonProperty("party_identifier")
    public void setPartyIdentifier(String partyIdentifier) {
        this.partyIdentifier = partyIdentifier;
    }

    public Source withPartyIdentifier(String partyIdentifier) {
        this.partyIdentifier = partyIdentifier;
        return this;
    }

    @JsonProperty("path_client_identifer")
    public String getPathClientIdentifer() {
        return pathClientIdentifer;
    }

    @JsonProperty("path_client_identifer")
    public void setPathClientIdentifer(String pathClientIdentifer) {
        this.pathClientIdentifer = pathClientIdentifer;
    }

    public Source withPathClientIdentifer(String pathClientIdentifer) {
        this.pathClientIdentifer = pathClientIdentifer;
        return this;
    }

    @JsonProperty("taxpayer_identifier_number")
    public String getTaxpayerIdentifierNumber() {
        return taxpayerIdentifierNumber;
    }

    @JsonProperty("taxpayer_identifier_number")
    public void setTaxpayerIdentifierNumber(String taxpayerIdentifierNumber) {
        this.taxpayerIdentifierNumber = taxpayerIdentifierNumber;
    }

    public Source withTaxpayerIdentifierNumber(String taxpayerIdentifierNumber) {
        this.taxpayerIdentifierNumber = taxpayerIdentifierNumber;
        return this;
    }

    @JsonProperty("producer_identifier")
    public String getProducerIdentifier() {
        return producerIdentifier;
    }

    @JsonProperty("producer_identifier")
    public void setProducerIdentifier(String producerIdentifier) {
        this.producerIdentifier = producerIdentifier;
    }

    public Source withProducerIdentifier(String producerIdentifier) {
        this.producerIdentifier = producerIdentifier;
        return this;
    }

    @JsonProperty("LeadFA_Producer_Identifier")
    public String getLeadFAProducerIdentifier() {
        return leadFAProducerIdentifier;
    }

    @JsonProperty("LeadFA_Producer_Identifier")
    public void setLeadFAProducerIdentifier(String leadFAProducerIdentifier) {
        this.leadFAProducerIdentifier = leadFAProducerIdentifier;
    }

    public Source withLeadFAProducerIdentifier(String leadFAProducerIdentifier) {
        this.leadFAProducerIdentifier = leadFAProducerIdentifier;
        return this;
    }

    @JsonProperty("individual_first_name")
    public String getIndividualFirstName() {
        return individualFirstName;
    }

    @JsonProperty("individual_first_name")
    public void setIndividualFirstName(String individualFirstName) {
        this.individualFirstName = individualFirstName;
    }

    public Source withIndividualFirstName(String individualFirstName) {
        this.individualFirstName = individualFirstName;
        return this;
    }

    @JsonProperty("individual_middle_name")
    public String getIndividualMiddleName() {
        return individualMiddleName;
    }

    @JsonProperty("individual_middle_name")
    public void setIndividualMiddleName(String individualMiddleName) {
        this.individualMiddleName = individualMiddleName;
    }

    public Source withIndividualMiddleName(String individualMiddleName) {
        this.individualMiddleName = individualMiddleName;
        return this;
    }

    @JsonProperty("individual_last_name")
    public String getIndividualLastName() {
        return individualLastName;
    }

    @JsonProperty("individual_last_name")
    public void setIndividualLastName(String individualLastName) {
        this.individualLastName = individualLastName;
    }

    public Source withIndividualLastName(String individualLastName) {
        this.individualLastName = individualLastName;
        return this;
    }

    @JsonProperty("individual_name_prefix")
    public String getIndividualNamePrefix() {
        return individualNamePrefix;
    }

    @JsonProperty("individual_name_prefix")
    public void setIndividualNamePrefix(String individualNamePrefix) {
        this.individualNamePrefix = individualNamePrefix;
    }

    public Source withIndividualNamePrefix(String individualNamePrefix) {
        this.individualNamePrefix = individualNamePrefix;
        return this;
    }

    @JsonProperty("individual_name_suffix")
    public String getIndividualNameSuffix() {
        return individualNameSuffix;
    }

    @JsonProperty("individual_name_suffix")
    public void setIndividualNameSuffix(String individualNameSuffix) {
        this.individualNameSuffix = individualNameSuffix;
    }

    public Source withIndividualNameSuffix(String individualNameSuffix) {
        this.individualNameSuffix = individualNameSuffix;
        return this;
    }

    @JsonProperty("individual_preferred_phone_number")
    public String getIndividualPreferredPhoneNumber() {
        return individualPreferredPhoneNumber;
    }

    @JsonProperty("individual_preferred_phone_number")
    public void setIndividualPreferredPhoneNumber(String individualPreferredPhoneNumber) {
        this.individualPreferredPhoneNumber = individualPreferredPhoneNumber;
    }

    public Source withIndividualPreferredPhoneNumber(String individualPreferredPhoneNumber) {
        this.individualPreferredPhoneNumber = individualPreferredPhoneNumber;
        return this;
    }

    @JsonProperty("individual_preferred_email_address")
    public String getIndividualPreferredEmailAddress() {
        return individualPreferredEmailAddress;
    }

    @JsonProperty("individual_preferred_email_address")
    public void setIndividualPreferredEmailAddress(String individualPreferredEmailAddress) {
        this.individualPreferredEmailAddress = individualPreferredEmailAddress;
    }

    public Source withIndividualPreferredEmailAddress(String individualPreferredEmailAddress) {
        this.individualPreferredEmailAddress = individualPreferredEmailAddress;
        return this;
    }

    @JsonProperty("primary_residential_address_line")
    public String getPrimaryResidentialAddressLine() {
        return primaryResidentialAddressLine;
    }

    @JsonProperty("primary_residential_address_line")
    public void setPrimaryResidentialAddressLine(String primaryResidentialAddressLine) {
        this.primaryResidentialAddressLine = primaryResidentialAddressLine;
    }

    public Source withPrimaryResidentialAddressLine(String primaryResidentialAddressLine) {
        this.primaryResidentialAddressLine = primaryResidentialAddressLine;
        return this;
    }

    @JsonProperty("primary_residential_address_city_name")
    public String getPrimaryResidentialAddressCityName() {
        return primaryResidentialAddressCityName;
    }

    @JsonProperty("primary_residential_address_city_name")
    public void setPrimaryResidentialAddressCityName(String primaryResidentialAddressCityName) {
        this.primaryResidentialAddressCityName = primaryResidentialAddressCityName;
    }

    public Source withPrimaryResidentialAddressCityName(String primaryResidentialAddressCityName) {
        this.primaryResidentialAddressCityName = primaryResidentialAddressCityName;
        return this;
    }

    @JsonProperty("primary_residential_address_state_code")
    public String getPrimaryResidentialAddressStateCode() {
        return primaryResidentialAddressStateCode;
    }

    @JsonProperty("primary_residential_address_state_code")
    public void setPrimaryResidentialAddressStateCode(String primaryResidentialAddressStateCode) {
        this.primaryResidentialAddressStateCode = primaryResidentialAddressStateCode;
    }

    public Source withPrimaryResidentialAddressStateCode(String primaryResidentialAddressStateCode) {
        this.primaryResidentialAddressStateCode = primaryResidentialAddressStateCode;
        return this;
    }

    @JsonProperty("primay_residential_address_state_name")
    public String getPrimayResidentialAddressStateName() {
        return primayResidentialAddressStateName;
    }

    @JsonProperty("primay_residential_address_state_name")
    public void setPrimayResidentialAddressStateName(String primayResidentialAddressStateName) {
        this.primayResidentialAddressStateName = primayResidentialAddressStateName;
    }

    public Source withPrimayResidentialAddressStateName(String primayResidentialAddressStateName) {
        this.primayResidentialAddressStateName = primayResidentialAddressStateName;
        return this;
    }

    @JsonProperty("primary_residential_address_postal_code")
    public String getPrimaryResidentialAddressPostalCode() {
        return primaryResidentialAddressPostalCode;
    }

    @JsonProperty("primary_residential_address_postal_code")
    public void setPrimaryResidentialAddressPostalCode(String primaryResidentialAddressPostalCode) {
        this.primaryResidentialAddressPostalCode = primaryResidentialAddressPostalCode;
    }

    public Source withPrimaryResidentialAddressPostalCode(String primaryResidentialAddressPostalCode) {
        this.primaryResidentialAddressPostalCode = primaryResidentialAddressPostalCode;
        return this;
    }

    @JsonProperty("primary_residential_address_country_name")
    public String getPrimaryResidentialAddressCountryName() {
        return primaryResidentialAddressCountryName;
    }

    @JsonProperty("primary_residential_address_country_name")
    public void setPrimaryResidentialAddressCountryName(String primaryResidentialAddressCountryName) {
        this.primaryResidentialAddressCountryName = primaryResidentialAddressCountryName;
    }

    public Source withPrimaryResidentialAddressCountryName(String primaryResidentialAddressCountryName) {
        this.primaryResidentialAddressCountryName = primaryResidentialAddressCountryName;
        return this;
    }

    @JsonProperty("ccdp_asset_type")
    public String getCcdpAssetType() {
        return ccdpAssetType;
    }

    @JsonProperty("ccdp_asset_type")
    public void setCcdpAssetType(String ccdpAssetType) {
        this.ccdpAssetType = ccdpAssetType;
    }

    public Source withCcdpAssetType(String ccdpAssetType) {
        this.ccdpAssetType = ccdpAssetType;
        return this;
    }

    @JsonProperty("Profile_affiliate_sharing_indicator")
    public String getProfileAffiliateSharingIndicator() {
        return profileAffiliateSharingIndicator;
    }

    @JsonProperty("Profile_affiliate_sharing_indicator")
    public void setProfileAffiliateSharingIndicator(String profileAffiliateSharingIndicator) {
        this.profileAffiliateSharingIndicator = profileAffiliateSharingIndicator;
    }

    public Source withProfileAffiliateSharingIndicator(String profileAffiliateSharingIndicator) {
        this.profileAffiliateSharingIndicator = profileAffiliateSharingIndicator;
        return this;
    }

    @JsonProperty("test_document_indicator")
    public String getTestDocumentIndicator() {
        return testDocumentIndicator;
    }

    @JsonProperty("test_document_indicator")
    public void setTestDocumentIndicator(String testDocumentIndicator) {
        this.testDocumentIndicator = testDocumentIndicator;
    }

    public Source withTestDocumentIndicator(String testDocumentIndicator) {
        this.testDocumentIndicator = testDocumentIndicator;
        return this;
    }

    @JsonProperty("test_case_identifier")
    public String getTestCaseIdentifier() {
        return testCaseIdentifier;
    }

    @JsonProperty("test_case_identifier")
    public void setTestCaseIdentifier(String testCaseIdentifier) {
        this.testCaseIdentifier = testCaseIdentifier;
    }

    public Source withTestCaseIdentifier(String testCaseIdentifier) {
        this.testCaseIdentifier = testCaseIdentifier;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Source withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(masterProfileIdentifer).append(partyIdentifier).append(pathClientIdentifer).append(taxpayerIdentifierNumber).append(producerIdentifier).append(leadFAProducerIdentifier).append(individualFirstName).append(individualMiddleName).append(individualLastName).append(individualNamePrefix).append(individualNameSuffix).append(individualPreferredPhoneNumber).append(individualPreferredEmailAddress).append(primaryResidentialAddressLine).append(primaryResidentialAddressCityName).append(primaryResidentialAddressStateCode).append(primayResidentialAddressStateName).append(primaryResidentialAddressPostalCode).append(primaryResidentialAddressCountryName).append(ccdpAssetType).append(profileAffiliateSharingIndicator).append(testDocumentIndicator).append(testCaseIdentifier).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Source) == false) {
            return false;
        }
        Source rhs = ((Source) other);
        return new EqualsBuilder().append(masterProfileIdentifer, rhs.masterProfileIdentifer).append(partyIdentifier, rhs.partyIdentifier).append(pathClientIdentifer, rhs.pathClientIdentifer).append(taxpayerIdentifierNumber, rhs.taxpayerIdentifierNumber).append(producerIdentifier, rhs.producerIdentifier).append(leadFAProducerIdentifier, rhs.leadFAProducerIdentifier).append(individualFirstName, rhs.individualFirstName).append(individualMiddleName, rhs.individualMiddleName).append(individualLastName, rhs.individualLastName).append(individualNamePrefix, rhs.individualNamePrefix).append(individualNameSuffix, rhs.individualNameSuffix).append(individualPreferredPhoneNumber, rhs.individualPreferredPhoneNumber).append(individualPreferredEmailAddress, rhs.individualPreferredEmailAddress).append(primaryResidentialAddressLine, rhs.primaryResidentialAddressLine).append(primaryResidentialAddressCityName, rhs.primaryResidentialAddressCityName).append(primaryResidentialAddressStateCode, rhs.primaryResidentialAddressStateCode).append(primayResidentialAddressStateName, rhs.primayResidentialAddressStateName).append(primaryResidentialAddressPostalCode, rhs.primaryResidentialAddressPostalCode).append(primaryResidentialAddressCountryName, rhs.primaryResidentialAddressCountryName).append(ccdpAssetType, rhs.ccdpAssetType).append(profileAffiliateSharingIndicator, rhs.profileAffiliateSharingIndicator).append(testDocumentIndicator, rhs.testDocumentIndicator).append(testCaseIdentifier, rhs.testCaseIdentifier).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
