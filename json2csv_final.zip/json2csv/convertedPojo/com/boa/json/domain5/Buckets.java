
package com.boa.json.domain5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "doc_count_error_upper_bound",
    "sum_other_doc_count",
    "buckets"
})
public class Buckets {

    @JsonProperty("doc_count_error_upper_bound")
    private Integer docCountErrorUpperBound;
    @JsonProperty("sum_other_doc_count")
    private Integer sumOtherDocCount;
    @JsonProperty("buckets")
    private List<Bucket> buckets = new ArrayList<Bucket>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("doc_count_error_upper_bound")
    public Integer getDocCountErrorUpperBound() {
        return docCountErrorUpperBound;
    }

    @JsonProperty("doc_count_error_upper_bound")
    public void setDocCountErrorUpperBound(Integer docCountErrorUpperBound) {
        this.docCountErrorUpperBound = docCountErrorUpperBound;
    }

    public Buckets withDocCountErrorUpperBound(Integer docCountErrorUpperBound) {
        this.docCountErrorUpperBound = docCountErrorUpperBound;
        return this;
    }

    @JsonProperty("sum_other_doc_count")
    public Integer getSumOtherDocCount() {
        return sumOtherDocCount;
    }

    @JsonProperty("sum_other_doc_count")
    public void setSumOtherDocCount(Integer sumOtherDocCount) {
        this.sumOtherDocCount = sumOtherDocCount;
    }

    public Buckets withSumOtherDocCount(Integer sumOtherDocCount) {
        this.sumOtherDocCount = sumOtherDocCount;
        return this;
    }

    @JsonProperty("buckets")
    public List<Bucket> getBuckets() {
        return buckets;
    }

    @JsonProperty("buckets")
    public void setBuckets(List<Bucket> buckets) {
        this.buckets = buckets;
    }

    public Buckets withBuckets(List<Bucket> buckets) {
        this.buckets = buckets;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Buckets withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(docCountErrorUpperBound).append(sumOtherDocCount).append(buckets).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Buckets) == false) {
            return false;
        }
        Buckets rhs = ((Buckets) other);
        return new EqualsBuilder().append(docCountErrorUpperBound, rhs.docCountErrorUpperBound).append(sumOtherDocCount, rhs.sumOtherDocCount).append(buckets, rhs.buckets).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
