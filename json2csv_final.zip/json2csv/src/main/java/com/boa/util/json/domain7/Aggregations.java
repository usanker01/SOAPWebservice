package com.boa.util.json.domain7;

public class Aggregations
{
    private Buckets buckets;

    public Buckets getBuckets ()
    {
        return buckets;
    }

    public void setBuckets (Buckets buckets)
    {
        this.buckets = buckets;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [buckets1 = "+buckets+"]";
    }
}