package com.boa.util.json.domain;
public class NGramTermPrrIdM
{
    private _hits _hits;

    private _shards _shards;

    private String timed_out;

    private String took;

    public _hits get_hits ()
    {
        return _hits;
    }

    public void set_hits (_hits _hits)
    {
        this._hits = _hits;
    }

    public _shards get_shards ()
    {
        return _shards;
    }

    public void set_shards (_shards _shards)
    {
        this._shards = _shards;
    }

    public String getTimed_out ()
    {
        return timed_out;
    }

    public void setTimed_out (String timed_out)
    {
        this.timed_out = timed_out;
    }

    public String getTook ()
    {
        return took;
    }

    public void setTook (String took)
    {
        this.took = took;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [_hits = "+_hits+", _shards = "+_shards+", timed_out = "+timed_out+", took = "+took+"]";
    }
}