package com.boa.util.json.domain6;

public class _shards
{
    private String total;

    private String skipped;

    private String failed;

    private String successful;

    public String getTotal ()
    {
        return total;
    }

    public void setTotal (String total)
    {
        this.total = total;
    }

    public String getSkipped ()
    {
        return skipped;
    }

    public void setSkipped (String skipped)
    {
        this.skipped = skipped;
    }

    public String getFailed ()
    {
        return failed;
    }

    public void setFailed (String failed)
    {
        this.failed = failed;
    }

    public String getSuccessful ()
    {
        return successful;
    }

    public void setSuccessful (String successful)
    {
        this.successful = successful;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [total = "+total+", skipped = "+skipped+", failed = "+failed+", successful = "+successful+"]";
    }
}