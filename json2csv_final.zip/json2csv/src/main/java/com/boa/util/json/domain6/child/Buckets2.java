package com.boa.util.json.domain6.child;

public class Buckets2
{
    private Significant_ngrams significant_ngrams;

    private String doc_count;

    private String key;

    public Significant_ngrams getSignificant_ngrams ()
    {
        return significant_ngrams;
    }

    public void setSignificant_ngrams (Significant_ngrams significant_ngrams)
    {
        this.significant_ngrams = significant_ngrams;
    }

    public String getDoc_count ()
    {
        return doc_count;
    }

    public void setDoc_count (String doc_count)
    {
        this.doc_count = doc_count;
    }

    public String getKey ()
    {
        return key;
    }

    public void setKey (String key)
    {
        this.key = key;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [significant_ngrams = "+significant_ngrams+", doc_count = "+doc_count+", key = "+key+"]";
    }
}
