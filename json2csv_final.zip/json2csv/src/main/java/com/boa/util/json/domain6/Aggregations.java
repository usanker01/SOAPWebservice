package com.boa.util.json.domain6;

public class Aggregations
{
    private Buckets1 buckets1;

    public Buckets1 getBuckets1 ()
    {
        return buckets1;
    }

    public void setBuckets1 (Buckets1 buckets1)
    {
        this.buckets1 = buckets1;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [buckets1 = "+buckets1+"]";
    }
}