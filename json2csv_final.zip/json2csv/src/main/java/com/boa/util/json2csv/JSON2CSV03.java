package com.boa.util.json2csv;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.boa.json.domain2.Input;
import com.boa.json.domain3.Ngram;
import com.boa.json.domain4.NgramFinal;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import org.json.CDL;
//import org.json.JSONArray;
//import org.json.JSONObject;
import org.json.JSONException;

/**
 * Hello world!
 *
 */
public class JSON2CSV03 
{
    public static void main( String[] args )
    {
    	try {
    		Gson gson = new Gson();
    		JsonElement jsonElement = gson.fromJson(new FileReader("files/ngram.json"), JsonElement.class);
    		String jsonElementStr = gson.toJson(jsonElement);
    		NgramFinal ngramFinal = gson.fromJson(jsonElementStr, NgramFinal.class);
    		System.out.println("NGRAMFinal->"+ngramFinal);
    		/*org.json.simple.parser.JSONParser parser = new JSONParser();
            Object object = parser.parse(new FileReader("files/ngran.JSONObject) object;
            String jsonStr=jsonObject.toJSONString();
                
            output = new org.json.JSONObject(jsonString);
            JSONArray docs = output.getJSONArray("infile");
            File file=new File("files/fromJSON.csv");
            String csv = CDL.toString(docs);
            FileUtils.writeStringToFile(file, csv);
            
            System.out.println("jsonStr->"+jsonStr);
            
            Gson gson=new Gson();
            Input input= gson.fromJson(jsonStr, Input.class);
            
            String inputStr = gson.toJson(input); // serializes target to Json
            System.out.println("inputStr->"+inputStr);*/
            
            /*org.json.JSONObject jsonObj=new org.json.JSONObject(ngramTermPrridAnalysisMValid2Str);
            org.json.JSONArray _hitsArray=jsonObj.getJSONArray("hits");
            File file=new File("files/outputCSV.csv");
            String csvStr=CDL.toString(_hitsArray);
            FileUtils.writeStringToFile(file, csvStr);*/
            
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }      
    	
    }
}
