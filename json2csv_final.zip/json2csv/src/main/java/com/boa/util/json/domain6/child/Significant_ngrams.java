package com.boa.util.json.domain6.child;

public class Significant_ngrams
{
    private String[] buckets;

    public String[] getBuckets ()
    {
        return buckets;
    }

    public void setBuckets (String[] buckets)
    {
        this.buckets = buckets;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [buckets = "+buckets+"]";
    }
}
