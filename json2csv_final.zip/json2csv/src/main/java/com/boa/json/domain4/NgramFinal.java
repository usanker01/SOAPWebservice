package com.boa.json.domain4;

public class NgramFinal
{
    private _shards _shards;

    private String timed_out;

    private String took;

    private _gits _gits;

    public _shards get_shards ()
    {
        return _shards;
    }

    public void set_shards (_shards _shards)
    {
        this._shards = _shards;
    }

    public String getTimed_out ()
    {
        return timed_out;
    }

    public void setTimed_out (String timed_out)
    {
        this.timed_out = timed_out;
    }

    public String getTook ()
    {
        return took;
    }

    public void setTook (String took)
    {
        this.took = took;
    }

    public _gits get_gits ()
    {
        return _gits;
    }

    public void set_gits (_gits _gits)
    {
        this._gits = _gits;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [_shards = "+_shards+", timed_out = "+timed_out+", took = "+took+", _gits = "+_gits+"]";
    }
}
