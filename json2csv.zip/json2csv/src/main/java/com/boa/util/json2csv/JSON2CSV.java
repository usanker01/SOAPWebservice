package com.boa.util.json2csv;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSON2CSV {
	
	public static void main(String myHelpers[]){
        String jsonString = "{\"infile\": [{\"field1\": 11,\"field2\": 12,\"field3\": 13},{\"field1\": 21,\"field2\": 22,\"field3\": 23},{\"field1\": 31,\"field2\": 32,\"field3\": 33}]}";

        org.json.JSONObject output;
        try {
        	
        	org.json.simple.parser.JSONParser parser = new JSONParser();
            Object object = parser.parse(new FileReader("files/ngram_term_prrid_analysis_valid.json"));
            
            org.json.simple.JSONObject jsonObject=(org.json.simple.JSONObject) object;
            
            String jsonObjectStr=jsonObject.toJSONString();
                
            output = new org.json.JSONObject(jsonString);


            JSONArray docs = output.getJSONArray("infile");

            File file=new File("files/fromJSON.csv");
            String csv = CDL.toString(docs);
            FileUtils.writeStringToFile(file, csv);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
    }

}
