package com.boa.util.json2csv;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.boa.util.json.domain.NGramTermPrrIdM;
import com.google.gson.Gson;

import org.json.CDL;
//import org.json.JSONArray;
//import org.json.JSONObject;
import org.json.JSONException;

/**
 * Hello world!
 *
 */
public class JSON2CSV 
{
    public static void main( String[] args )
    {
    	try {
        	
        	org.json.simple.parser.JSONParser parser = new JSONParser();
            Object object = parser.parse(new FileReader("files/ngram_term_prrid_analysis_M_valid2.json"));
            org.json.simple.JSONObject jsonObject=(org.json.simple.JSONObject) object;
            String jsonStr=jsonObject.toJSONString();
                
            /*output = new org.json.JSONObject(jsonString);
            JSONArray docs = output.getJSONArray("infile");
            File file=new File("files/fromJSON.csv");
            String csv = CDL.toString(docs);
            FileUtils.writeStringToFile(file, csv);*/
            
            System.out.println("jsonStr->"+jsonStr);
            
            Gson gson=new Gson();
            NGramTermPrrIdM NGramTermPrrIdMObj= gson.fromJson(jsonStr, NGramTermPrrIdM.class);
            
            String NGramTermPrrIdMStr = gson.toJson(NGramTermPrrIdMObj); // serializes target to Json
            System.out.println("NGramTermPrrIdMStr->"+NGramTermPrrIdMStr);
            
            org.json.JSONObject jsonObj=new org.json.JSONObject(NGramTermPrrIdMStr);
            org.json.JSONArray _hitsArray=jsonObj.getJSONArray("hits");
            File file=new File("files/outputCSV.csv");
            String csvStr=CDL.toString(_hitsArray);
            FileUtils.writeStringToFile(file, csvStr);
            
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
    	
    }
}
