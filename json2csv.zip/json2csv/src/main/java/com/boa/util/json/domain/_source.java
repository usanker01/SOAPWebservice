package com.boa.util.json.domain;
public class _source
{
    private String taxpayer_identifier_number;

    private String Profile_affiliate_sharing_indicator;

    private String individual_last_name;

    private String path_client_identifer;

    private String individual_name_prefix;

    private String test_case_identifier;

    private String master_profile_identifer;

    private String individual_preferred_email_address;

    private String primary_residential_address_postal_code;

    private String party_identifier;

    private String LeadFA_Producer_Identifier;

    private String test_document_indicator;

    private String individual_middle_name;

    private String primary_residential_address_city_name;

    private String primary_residential_address_country_name;

    private String primay_residential_address_state_name;

    private String ccdp_asset_type;

    private String primary_residential_address_line;

    private String individual_first_name;

    private String individual_name_suffix;

    private String producer_identifier;

    private String primary_residential_address_state_code;

    private String individual_preferred_phone_number;

    public String getTaxpayer_identifier_number ()
    {
        return taxpayer_identifier_number;
    }

    public void setTaxpayer_identifier_number (String taxpayer_identifier_number)
    {
        this.taxpayer_identifier_number = taxpayer_identifier_number;
    }

    public String getProfile_affiliate_sharing_indicator ()
    {
        return Profile_affiliate_sharing_indicator;
    }

    public void setProfile_affiliate_sharing_indicator (String Profile_affiliate_sharing_indicator)
    {
        this.Profile_affiliate_sharing_indicator = Profile_affiliate_sharing_indicator;
    }

    public String getIndividual_last_name ()
    {
        return individual_last_name;
    }

    public void setIndividual_last_name (String individual_last_name)
    {
        this.individual_last_name = individual_last_name;
    }

    public String getPath_client_identifer ()
    {
        return path_client_identifer;
    }

    public void setPath_client_identifer (String path_client_identifer)
    {
        this.path_client_identifer = path_client_identifer;
    }

    public String getIndividual_name_prefix ()
    {
        return individual_name_prefix;
    }

    public void setIndividual_name_prefix (String individual_name_prefix)
    {
        this.individual_name_prefix = individual_name_prefix;
    }

    public String getTest_case_identifier ()
    {
        return test_case_identifier;
    }

    public void setTest_case_identifier (String test_case_identifier)
    {
        this.test_case_identifier = test_case_identifier;
    }

    public String getMaster_profile_identifer ()
    {
        return master_profile_identifer;
    }

    public void setMaster_profile_identifer (String master_profile_identifer)
    {
        this.master_profile_identifer = master_profile_identifer;
    }

    public String getIndividual_preferred_email_address ()
    {
        return individual_preferred_email_address;
    }

    public void setIndividual_preferred_email_address (String individual_preferred_email_address)
    {
        this.individual_preferred_email_address = individual_preferred_email_address;
    }

    public String getPrimary_residential_address_postal_code ()
    {
        return primary_residential_address_postal_code;
    }

    public void setPrimary_residential_address_postal_code (String primary_residential_address_postal_code)
    {
        this.primary_residential_address_postal_code = primary_residential_address_postal_code;
    }

    public String getParty_identifier ()
    {
        return party_identifier;
    }

    public void setParty_identifier (String party_identifier)
    {
        this.party_identifier = party_identifier;
    }

    public String getLeadFA_Producer_Identifier ()
    {
        return LeadFA_Producer_Identifier;
    }

    public void setLeadFA_Producer_Identifier (String LeadFA_Producer_Identifier)
    {
        this.LeadFA_Producer_Identifier = LeadFA_Producer_Identifier;
    }

    public String getTest_document_indicator ()
    {
        return test_document_indicator;
    }

    public void setTest_document_indicator (String test_document_indicator)
    {
        this.test_document_indicator = test_document_indicator;
    }

    public String getIndividual_middle_name ()
    {
        return individual_middle_name;
    }

    public void setIndividual_middle_name (String individual_middle_name)
    {
        this.individual_middle_name = individual_middle_name;
    }

    public String getPrimary_residential_address_city_name ()
    {
        return primary_residential_address_city_name;
    }

    public void setPrimary_residential_address_city_name (String primary_residential_address_city_name)
    {
        this.primary_residential_address_city_name = primary_residential_address_city_name;
    }

    public String getPrimary_residential_address_country_name ()
    {
        return primary_residential_address_country_name;
    }

    public void setPrimary_residential_address_country_name (String primary_residential_address_country_name)
    {
        this.primary_residential_address_country_name = primary_residential_address_country_name;
    }

    public String getPrimay_residential_address_state_name ()
    {
        return primay_residential_address_state_name;
    }

    public void setPrimay_residential_address_state_name (String primay_residential_address_state_name)
    {
        this.primay_residential_address_state_name = primay_residential_address_state_name;
    }

    public String getCcdp_asset_type ()
    {
        return ccdp_asset_type;
    }

    public void setCcdp_asset_type (String ccdp_asset_type)
    {
        this.ccdp_asset_type = ccdp_asset_type;
    }

    public String getPrimary_residential_address_line ()
    {
        return primary_residential_address_line;
    }

    public void setPrimary_residential_address_line (String primary_residential_address_line)
    {
        this.primary_residential_address_line = primary_residential_address_line;
    }

    public String getIndividual_first_name ()
    {
        return individual_first_name;
    }

    public void setIndividual_first_name (String individual_first_name)
    {
        this.individual_first_name = individual_first_name;
    }

    public String getIndividual_name_suffix ()
    {
        return individual_name_suffix;
    }

    public void setIndividual_name_suffix (String individual_name_suffix)
    {
        this.individual_name_suffix = individual_name_suffix;
    }

    public String getProducer_identifier ()
    {
        return producer_identifier;
    }

    public void setProducer_identifier (String producer_identifier)
    {
        this.producer_identifier = producer_identifier;
    }

    public String getPrimary_residential_address_state_code ()
    {
        return primary_residential_address_state_code;
    }

    public void setPrimary_residential_address_state_code (String primary_residential_address_state_code)
    {
        this.primary_residential_address_state_code = primary_residential_address_state_code;
    }

    public String getIndividual_preferred_phone_number ()
    {
        return individual_preferred_phone_number;
    }

    public void setIndividual_preferred_phone_number (String individual_preferred_phone_number)
    {
        this.individual_preferred_phone_number = individual_preferred_phone_number;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [taxpayer_identifier_number = "+taxpayer_identifier_number+", Profile_affiliate_sharing_indicator = "+Profile_affiliate_sharing_indicator+", individual_last_name = "+individual_last_name+", path_client_identifer = "+path_client_identifer+", individual_name_prefix = "+individual_name_prefix+", test_case_identifier = "+test_case_identifier+", master_profile_identifer = "+master_profile_identifer+", individual_preferred_email_address = "+individual_preferred_email_address+", primary_residential_address_postal_code = "+primary_residential_address_postal_code+", party_identifier = "+party_identifier+", LeadFA_Producer_Identifier = "+LeadFA_Producer_Identifier+", test_document_indicator = "+test_document_indicator+", individual_middle_name = "+individual_middle_name+", primary_residential_address_city_name = "+primary_residential_address_city_name+", primary_residential_address_country_name = "+primary_residential_address_country_name+", primay_residential_address_state_name = "+primay_residential_address_state_name+", ccdp_asset_type = "+ccdp_asset_type+", primary_residential_address_line = "+primary_residential_address_line+", individual_first_name = "+individual_first_name+", individual_name_suffix = "+individual_name_suffix+", producer_identifier = "+producer_identifier+", primary_residential_address_state_code = "+primary_residential_address_state_code+", individual_preferred_phone_number = "+individual_preferred_phone_number+"]";
    }
}