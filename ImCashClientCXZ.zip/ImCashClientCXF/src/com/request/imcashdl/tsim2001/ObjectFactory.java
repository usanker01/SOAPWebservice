
package com.request.imcashdl.tsim2001;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.request.imcashdl.tsim2001 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _TSIM2001Operation_QNAME = new QName("http://www.TSIM2001.IMCASHDL.Request.com", "TSIM2001Operation");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.request.imcashdl.tsim2001
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProgramInterface }
     * 
     */
    public ProgramInterface createProgramInterface() {
        return new ProgramInterface();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord }
     * 
     */
    public ProgramInterface.DlrRecord createProgramInterfaceDlrRecord() {
        return new ProgramInterface.DlrRecord();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction createProgramInterfaceDlrRecordDlrTransaction() {
        return new ProgramInterface.DlrRecord.DlrTransaction();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran createProgramInterfaceDlrRecordDlrTransactionDlrDescTran() {
        return new ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey createProgramInterfaceDlrRecordDlrTransactionDlrCtlKey() {
        return new ProgramInterface.DlrRecord.DlrTransaction.DlrCtlKey();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran createProgramInterfaceDlrRecordDlrTransactionDlr80Tran() {
        return new ProgramInterface.DlrRecord.DlrTransaction.Dlr80Tran();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo createProgramInterfaceDlrRecordDlrTransactionDlrSourceInfo() {
        return new ProgramInterface.DlrRecord.DlrTransaction.DlrSourceInfo();
    }

    /**
     * Create an instance of {@link ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc }
     * 
     */
    public ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc createProgramInterfaceDlrRecordDlrTransactionDlrDescTranDlrUnivDesc() {
        return new ProgramInterface.DlrRecord.DlrTransaction.DlrDescTran.DlrUnivDesc();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProgramInterface }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.TSIM2001.IMCASHDL.Request.com", name = "TSIM2001Operation")
    public JAXBElement<ProgramInterface> createTSIM2001Operation(ProgramInterface value) {
        return new JAXBElement<ProgramInterface>(_TSIM2001Operation_QNAME, ProgramInterface.class, null, value);
    }

}
