
package com.response.imcashob.tsim2001;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgramInterface complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProgramInterface">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cash_outbound_record">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="cash_ob_message">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="cash_ob_return_text">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;maxLength value="30"/>
 *                                   &lt;whiteSpace value="collapse"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                             &lt;element name="cash_ob_return_code">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;maxLength value="2"/>
 *                                   &lt;whiteSpace value="collapse"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                             &lt;element name="cash_ob_bus_day_text">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;maxLength value="22"/>
 *                                   &lt;whiteSpace value="collapse"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                             &lt;element name="cash_ob_txn_date">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;maxLength value="8"/>
 *                                   &lt;whiteSpace value="collapse"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProgramInterface", propOrder = {
    "cashOutboundRecord"
})
public class ProgramInterface {

    @XmlElement(name = "cash_outbound_record", required = true)
    protected ProgramInterface.CashOutboundRecord cashOutboundRecord;

    /**
     * Gets the value of the cashOutboundRecord property.
     * 
     * @return
     *     possible object is
     *     {@link ProgramInterface.CashOutboundRecord }
     *     
     */
    public ProgramInterface.CashOutboundRecord getCashOutboundRecord() {
        return cashOutboundRecord;
    }

    /**
     * Sets the value of the cashOutboundRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProgramInterface.CashOutboundRecord }
     *     
     */
    public void setCashOutboundRecord(ProgramInterface.CashOutboundRecord value) {
        this.cashOutboundRecord = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="cash_ob_message">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="cash_ob_return_text">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;maxLength value="30"/>
     *                         &lt;whiteSpace value="collapse"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                   &lt;element name="cash_ob_return_code">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;maxLength value="2"/>
     *                         &lt;whiteSpace value="collapse"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                   &lt;element name="cash_ob_bus_day_text">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;maxLength value="22"/>
     *                         &lt;whiteSpace value="collapse"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                   &lt;element name="cash_ob_txn_date">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;maxLength value="8"/>
     *                         &lt;whiteSpace value="collapse"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "cashObMessage"
    })
    public static class CashOutboundRecord {

        @XmlElement(name = "cash_ob_message", required = true)
        protected ProgramInterface.CashOutboundRecord.CashObMessage cashObMessage;

        /**
         * Gets the value of the cashObMessage property.
         * 
         * @return
         *     possible object is
         *     {@link ProgramInterface.CashOutboundRecord.CashObMessage }
         *     
         */
        public ProgramInterface.CashOutboundRecord.CashObMessage getCashObMessage() {
            return cashObMessage;
        }

        /**
         * Sets the value of the cashObMessage property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProgramInterface.CashOutboundRecord.CashObMessage }
         *     
         */
        public void setCashObMessage(ProgramInterface.CashOutboundRecord.CashObMessage value) {
            this.cashObMessage = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="cash_ob_return_text">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;maxLength value="30"/>
         *               &lt;whiteSpace value="collapse"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *         &lt;element name="cash_ob_return_code">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;maxLength value="2"/>
         *               &lt;whiteSpace value="collapse"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *         &lt;element name="cash_ob_bus_day_text">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;maxLength value="22"/>
         *               &lt;whiteSpace value="collapse"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *         &lt;element name="cash_ob_txn_date">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;maxLength value="8"/>
         *               &lt;whiteSpace value="collapse"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "cashObReturnText",
            "cashObReturnCode",
            "cashObBusDayText",
            "cashObTxnDate"
        })
        public static class CashObMessage {

            @XmlElement(name = "cash_ob_return_text", required = true)
            protected String cashObReturnText;
            @XmlElement(name = "cash_ob_return_code", required = true)
            protected String cashObReturnCode;
            @XmlElement(name = "cash_ob_bus_day_text", required = true)
            protected String cashObBusDayText;
            @XmlElement(name = "cash_ob_txn_date", required = true)
            protected String cashObTxnDate;

            /**
             * Gets the value of the cashObReturnText property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCashObReturnText() {
                return cashObReturnText;
            }

            /**
             * Sets the value of the cashObReturnText property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCashObReturnText(String value) {
                this.cashObReturnText = value;
            }

            /**
             * Gets the value of the cashObReturnCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCashObReturnCode() {
                return cashObReturnCode;
            }

            /**
             * Sets the value of the cashObReturnCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCashObReturnCode(String value) {
                this.cashObReturnCode = value;
            }

            /**
             * Gets the value of the cashObBusDayText property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCashObBusDayText() {
                return cashObBusDayText;
            }

            /**
             * Sets the value of the cashObBusDayText property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCashObBusDayText(String value) {
                this.cashObBusDayText = value;
            }

            /**
             * Gets the value of the cashObTxnDate property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCashObTxnDate() {
                return cashObTxnDate;
            }

            /**
             * Sets the value of the cashObTxnDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCashObTxnDate(String value) {
                this.cashObTxnDate = value;
            }

        }

    }

}
